const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const config = {
    user: 'USERDB',
    password: 'PASSWORD',
    connectString: 'localhost:1521/xe'
};

app.get('/equipos', async (req, res) => {
    let connection;
    try {
        connection = await oracledb.getConnection(config);
        const result = await connection.execute('SELECT * FROM Equipo');
        res.json(result.rows);
    } catch (err) {
        console.error('Error al conectar a Oracle:', err);
        res.status(500).send('Error al conectar a Oracle');
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error('Error al cerrar la conexión:', err);
            }
        }
    }
});

app.post('/equipos', async (req, res) => {
    const { TipoDeEquipo, numSerie, estado } = req.body;
    try {
        const connection = await oracledb.getConnection(config);
        await connection.execute(
            `INSERT INTO Equipo (TipoDeEquipo, numSerie, estado) VALUES (:1, :2, :3)`,
            [TipoDeEquipo, numSerie, estado],
            { autoCommit: true }
        );
        res.status(201).send('Equipo agregado correctamente');
        await connection.close();
    } catch (err) {
        console.error('Error al agregar equipo:', err);
        res.status(500).send('Error al agregar equipo');
    }
});

app.delete('/equipos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const connection = await oracledb.getConnection(config);
        await connection.execute(
            `DELETE FROM Equipo WHERE EquipoID = :1`,
            [id],
            { autoCommit: true }
        );
        res.send('Equipo eliminado correctamente');
        await connection.close();
    } catch (err) {
        console.error('Error al eliminar equipo:', err);
        res.status(500).send('Error al eliminar equipo');
    }
});

app.listen(3001, () => {
    console.log('Servidor corriendo en el puerto 3001');
});
